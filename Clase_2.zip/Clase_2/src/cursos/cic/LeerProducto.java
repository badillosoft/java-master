/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cursos.cic;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 * @author Aula E5
 */
public class LeerProducto {
    public static void main(String[] args) 
            throws FileNotFoundException, IOException {
        DataInputStream in = new DataInputStream(
            new BufferedInputStream(
                new FileInputStream("C:\\test\\prod.dat")
            )
        );
        
        int id = in.readInt();
        String nombre = in.readUTF();
        double precioU = in.readDouble();
        double precioC = in.readDouble();
        
        in.close();
        
        System.out.format("Producto: %d | Nombre: %s | Precio: %.1f / %.1f%n",
                id, nombre, precioU, precioC);
    }
}
