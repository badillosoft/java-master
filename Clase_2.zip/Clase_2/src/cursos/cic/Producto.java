/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cursos.cic;

import java.io.Serializable;

/**
 *
 * @author Aula E5
 */
public class Producto implements Serializable {
    public int Id;
    public String Nombre;
    public double PrecioU;
    public double PrecioC;
}
