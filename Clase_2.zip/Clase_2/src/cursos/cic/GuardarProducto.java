/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cursos.cic;

import java.io.*;

/**
 *
 * @author Aula E5
 */
public class GuardarProducto {
    public static void main(String[] args) 
            throws FileNotFoundException, IOException {
        DataOutputStream out = new DataOutputStream(
            new BufferedOutputStream(
                new FileOutputStream("C:\\test\\prod.dat")
            )
        );
        
        out.writeInt(166890);
        out.writeUTF("Droga-Cola");
        out.writeDouble(7.5);
        out.writeDouble(10.5);
        
        out.close();
    }
}
