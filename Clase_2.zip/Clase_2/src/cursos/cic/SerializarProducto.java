/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cursos.cic;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author Aula E5
 */
public class SerializarProducto {
    public static void main(String[] args) throws IOException {
        ObjectOutputStream out = new ObjectOutputStream(
            new FileOutputStream("C:\\test\\prod2.dat")
        );
        
        Producto obj = new Producto();
        
        obj.Id = 123456;
        obj.Nombre = "Galletas Marias";
        obj.PrecioU = 8.75;
        obj.PrecioC = 12;
        
        out.writeObject(obj);
        
        out.close();
    }
}
