/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cursos.cic;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 *
 * @author Aula E5
 */
public class DeserializarProducto {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(
            new FileInputStream("C:\\test\\prod2.dat")
        );
        
        Producto prod = (Producto)in.readObject();
        
        in.close();
        
        System.out.format("%s%n", prod.Nombre);
    }
}
