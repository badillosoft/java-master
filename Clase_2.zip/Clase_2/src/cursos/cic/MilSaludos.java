/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cursos.cic;

/**
 *
 * @author Aula E5
 */
public class MilSaludos {
    static void mil_saludos(Saludable s) {
        for (int i = 0; i < 1000; i++) {
            s.saludar();
        }
    }
    
    public static void main(String[] args) {
        mil_saludos(new C());
    }
}
