/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cic;

import java.lang.management.*;
import java.sql.*;
import java.util.Date;
import javax.management.*;

public class Hello implements HelloMBean {

    @Override
    public String saludar() {
        return "Hola mundo";
    }
    
    @Override
    public int convierte(int x) {
        state = x % 2 == 0;
        
        return x * x;
    }

    boolean state = false;
    
    @Override
    public boolean getState() {
        return state;
    }
    
    public static void main(String[] args) throws MalformedObjectNameException, InstanceAlreadyExistsException, MBeanRegistrationException, NotCompliantMBeanException {
        MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
        
        ObjectName name = new ObjectName("com.cic:type=Hello");
        
        Hello hello = new Hello();
        
        mbs.registerMBean(hello, name);
        
        while(true) {}
    }

    @Override
    public double suma(double a, double b) {
        return a + b;
    }

    @Override
    public Date hora() {
        return new Date();
    }

    @Override
    public String test() {
        String result = "";
        try {
            String url = "jdbc:sqlserver://localhost:1433;" +
                    "databaseName=cic;user=sa;password=sasa;";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection(url,"sa","sasa");
            Statement stmt = conn.createStatement();
            ResultSet rs;
 
            rs = stmt.executeQuery("SELECT * FROM test");
           
            while ( rs.next() ) {
                String name = rs.getString("name");
                String value = rs.getString("value");
                result += String.format("%s(%s)%n", name, value);
            }
            conn.close();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }
        return result;
    }
    
}
