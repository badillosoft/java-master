/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cic;

import java.util.Date;

public interface HelloMBean {
    
    String saludar();
    
    int convierte(int x);
    
    boolean getState();
    
    double suma(double a, double b);
    
    Date hora();
    
    String test();
    
}
