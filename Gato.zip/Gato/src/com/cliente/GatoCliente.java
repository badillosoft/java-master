/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cliente;

import com.cic.IGatoCliente;
import com.cic.IGatoServidor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aula E5
 */
public class GatoCliente extends UnicastRemoteObject implements IGatoCliente {

    GatoClienteForm form;
    IGatoServidor server;
    
    public GatoCliente(GatoClienteForm form) throws RemoteException, NotBoundException {
        super();
        
        this.form = form;
        
        Registry registry = LocateRegistry.getRegistry("148.204.63.97", 1099);
        
        server = (IGatoServidor)registry.lookup("gato");
        
        int jugador = server.ingresar(this);
        
        System.out.format("Jugador: %d%n", jugador);
        
        form.jButton1.addActionListener((ActionEvent evt) -> {tirar(jugador, 1, 1);});
        form.jButton2.addActionListener((ActionEvent evt) -> {tirar(jugador, 1, 2);});
        form.jButton3.addActionListener((ActionEvent evt) -> {tirar(jugador, 1, 3);});
        form.jButton4.addActionListener((ActionEvent evt) -> {tirar(jugador, 2, 1);});
        form.jButton5.addActionListener((ActionEvent evt) -> {tirar(jugador, 2, 2);});
        form.jButton6.addActionListener((ActionEvent evt) -> {tirar(jugador, 2, 3);});
        form.jButton7.addActionListener((ActionEvent evt) -> {tirar(jugador, 3, 1);});
        form.jButton8.addActionListener((ActionEvent evt) -> {tirar(jugador, 3, 2);});
        form.jButton9.addActionListener((ActionEvent evt) -> {tirar(jugador, 3, 3);});
    }
    
    void tirar(int jugador, int fila, int columna) {
        try {
            server.tirar(jugador, fila, columna);
        } catch (RemoteException ex) {
            Logger.getLogger(GatoCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public void tu_turno() throws RemoteException {
        form.jLabel1.setText("Tu turno");
    }

    @Override
    public void ganaste() throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void perdiste() throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void empate() throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actualizar(int fila, int columna, char simbolo) throws RemoteException {
        System.out.format("Actualizar: %d %d %c %n", fila, columna, simbolo);
        form.jLabel1.setText("Esperando...");
        if (fila == 1 && columna == 1) {
            form.jButton1.setText("" + simbolo);
            form.jButton1.setEnabled(false);
        } else if (fila == 1 && columna == 2) {
            form.jButton2.setText("" + simbolo);
            form.jButton2.setEnabled(false);
        }  else if (fila == 1 && columna == 3) {
            form.jButton3.setText("" + simbolo);
            form.jButton3.setEnabled(false);
        } else if (fila == 2 && columna == 1) {
            form.jButton4.setText("" + simbolo);
            form.jButton4.setEnabled(false);
        } else if (fila == 2 && columna == 2) {
            form.jButton5.setText("" + simbolo);
            form.jButton5.setEnabled(false);
        } else if (fila == 2 && columna == 3) {
            form.jButton6.setText("" + simbolo);
            form.jButton6.setEnabled(false);
        } else if (fila == 3 && columna == 1) {
            form.jButton7.setText("" + simbolo);
            form.jButton7.setEnabled(false);
        } else if (fila == 3 && columna == 2) {
            form.jButton8.setText("" + simbolo);
            form.jButton8.setEnabled(false);
        } else if (fila == 3 && columna == 3) {
            form.jButton9.setText("" + simbolo);
            form.jButton9.setEnabled(false);
        }
    }
    
}
