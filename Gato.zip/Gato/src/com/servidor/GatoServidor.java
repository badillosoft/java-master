/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.servidor;

import com.cic.IGatoCliente;
import com.cic.IGatoServidor;
import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author Aula E5
 */
public class GatoServidor extends UnicastRemoteObject implements IGatoServidor {

    public GatoServidor() throws RemoteException {
        super();
    }
    
    IGatoCliente jugador1;
    IGatoCliente jugador2;
    int jugadores = 0;
    int turno = 0;
    
    @Override
    public int ingresar(IGatoCliente jugador) throws RemoteException {
        if (jugadores >= 2) {
            return -1;
        }
        
        if (jugadores == 0) {
            jugador1 = jugador;
            jugadores = 1;
            return 1;
        }
        
        jugador2 = jugador;
        jugadores = 2;
        
        siguiente_turno();
        
        return 2;
    }
    
    void siguiente_turno() throws RemoteException {
        if (turno == 0 || turno == 2) {
            turno = 1;
            jugador1.tu_turno();
            return;
        }
        
        turno = 2;
        jugador2.tu_turno();
    }

    @Override
    public boolean tirar(int jugador, int fila, int columna) throws RemoteException {
        if (turno != jugador) {
            return false;
        }
        
        char simbolo = jugador == 1 ? 'O' : 'X';
        
        jugador1.actualizar(fila, columna, simbolo);
        jugador2.actualizar(fila, columna, simbolo);
        
        // TODO: Checar que se pueda tirar en la casilla
        // TODO: Checar si el jugador gana-pierde
        // TODO: Checar si hay empate
        
        siguiente_turno();
        
        return true;
    }
    
    public static void main(String[] args) throws RemoteException, AlreadyBoundException, MalformedURLException {
        LocateRegistry.createRegistry(1099);
        
        GatoServidor server = new GatoServidor();
        
        Naming.bind("gato", server);
    }
    
}
