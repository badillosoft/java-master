/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cic;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Aula E5
 */
public interface IGatoServidor extends Remote {
    
    int ingresar(IGatoCliente jugador) throws RemoteException;
    
    boolean tirar(int jugador, int fila, int columna) throws RemoteException;
    
}
