/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cic;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Aula E5
 */
public interface IGatoCliente extends Remote {
    
    void tu_turno() throws RemoteException;
    
    void ganaste() throws RemoteException;
    
    void perdiste() throws RemoteException;
    
    void empate() throws RemoteException;
    
    void actualizar(int fila, int columna, char simbolo) throws RemoteException;
    
}
