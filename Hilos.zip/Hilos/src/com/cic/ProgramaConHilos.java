/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cic;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aula E5
 */
public class ProgramaConHilos implements Runnable {

    void tarea() throws InterruptedException {
        System.out.println("OK");
        Thread.sleep(2000);
    }
    
    @Override
    public void run() {
        try {
            this.tarea();
        } catch (InterruptedException ex) {
            // :(
        }
    }
    
    public static void main(String[] args) {
        for (int i = 0; i < 10000; i++) {
            Thread t = new Thread(new ProgramaConHilos());
            
            t.start();
        }
    }
    
}
