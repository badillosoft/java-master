/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cic;

/**
 *
 * @author Aula E5
 */
public class ProgramaSinHilos {
    void tarea() throws InterruptedException {
        System.out.println("OK");
        Thread.sleep(2000);
    }
    
    public static void main(String[] args) throws InterruptedException {
        ProgramaSinHilos psh = new ProgramaSinHilos();
        for (int i = 0; i < 10; i++) {
            psh.tarea();
        }
    }
}
