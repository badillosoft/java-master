/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cic;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aula E5
 */
public class Reloj extends Thread {
    
    Contador cont = new Contador();
    boolean encendido = true;
    Contadores form;
    int id;
    
    public Reloj(Contadores form, int id) {
        this.form = form;
        this.id = id;
    }
    
    @Override
    public void run() {
        while(encendido) {
            cont.tick();
            if (cont.c == 10) {
                encendido = false;
            }
            //System.out.println(cont);
            if (id == 1) {
                form.jLabel1.setText(cont.toString());
            } else {
                form.jLabel2.setText(cont.toString());
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                // :(
            }
        }
    }
    
    public void apagar() {
        encendido = false;
    }
    
}
