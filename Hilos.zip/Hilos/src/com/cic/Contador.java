/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cic;

/**
 *
 * @author Aula E5
 */
public class Contador {
    
    int c = 0;
    
    public void tick() {
        c++;
    }
    
    @Override
    public String toString() {
        int m = (int)(c / 60);
        int s = c % 60;
        
        String ms = (m < 10 ? "0" : "") + m;
        String ss = (s < 10 ? "0" : "") + s;
        
        return String.format("%s:%s", ms, ss);
    }
    
    public static void main(String[] args) {
        Contador cont = new Contador();
        for (int i = 0; i < 200; i++) {
            cont.tick();
            System.out.println(cont);
        }
    }
    
}
