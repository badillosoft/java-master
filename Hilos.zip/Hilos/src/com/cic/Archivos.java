/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cic;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aula E5
 */
public class Archivador extends Thread {
    void archivar() throws FileNotFoundException, IOException {
        String name = UUID.randomUUID().toString();
        
        String filename = "C:\\test\\" + name + ".txt";
        
        BufferedOutputStream f = new BufferedOutputStream(
                new FileOutputStream(filename)
        );
        
        Random r = new Random();
        
        for (int i = 0; i < 1000; i++) {
            for (int j = 0; j < 1000; j++) {
                f.write(r.nextInt());
            }
        }
        
        f.close();
    }
    
    public void run() {
        try {
            this.archivar();
        } catch (IOException ex) {
            // :(
        }
    }
    
    public static void main(String[] args) throws IOException {
        for (int i = 0; i < 100; i++) {
            Archivador arch = new Archivador();
            arch.archivar();
            //arch.start();
        }
    }
}
