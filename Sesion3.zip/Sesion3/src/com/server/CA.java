/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.server;

import com.cic.A;
import com.cic.B;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author Aula E5
 */
public class CA extends UnicastRemoteObject implements A {

    public CA() throws RemoteException {
        super();
    }
    
    int contador = 0;
    
    @Override
    public int a1(String mensaje) {
        System.out.format("BS Cliente dice: %s%n", mensaje);
        return this.contador++;
    }

    @Override
    public boolean a2(B b) throws RemoteException {
        b.b1(this.contador);
        System.out.println(b.b2("Hola mundo BS"));
        return true;
    }
    
}
