/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.server;

import com.cic.IChat;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class Chat extends UnicastRemoteObject implements IChat {
    
    public Chat() throws RemoteException {
        super();
    }
    
    ArrayList<String> nicks = new ArrayList();

    @Override
    public boolean entrar(String nick) throws RemoteException {
        if (nicks.size() >= 10) {
            return false;
        }
        
        for (String n : nicks) {
            if (n == null ? nick == null : n.equals(nick)) {
                return false;
            }
        }
        
        nicks.add(nick);
        return true;
    }

    @Override
    public ArrayList<String> lista() throws RemoteException {
        return nicks;
    }
    
}
