/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.client;

import com.cic.A;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author Aula E5
 */
public class Client {
    public static void main(String[] args) throws NotBoundException, MalformedURLException, RemoteException {
        Registry registry = LocateRegistry.getRegistry("148.204.63.97", 1099);
        
        A a = (A)registry.lookup("CA");
        
        int contador = a.a1("Hola soy el cliente");
        
        System.out.println(contador);
        
        CB b = new CB();
        
        a.a2(b);
    }
}
