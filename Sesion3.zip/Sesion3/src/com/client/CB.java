/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.client;

import com.cic.B;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author Aula E5
 */
public class CB extends UnicastRemoteObject implements B {

    public CB() throws RemoteException {
        super();
    }
    
    @Override
    public void b1(int x) {
        System.out.format("x: %d%n", x);
    }

    @Override
    public boolean b2(String mensaje) {
        System.out.format("Cliente: %s%n", mensaje);
        return false;
    }
    
}
