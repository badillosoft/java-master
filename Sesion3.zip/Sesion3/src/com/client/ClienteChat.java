/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.client;

import com.cic.IChat;
import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;

/**
 *
 * @author Aula E5
 */
public class ClienteChat {
    public static void main(String[] args) throws RemoteException, AlreadyBoundException, MalformedURLException, NotBoundException  {
        Registry registry = LocateRegistry.getRegistry("148.204.63.97", 1099); // host = 192.168.0.1, port = 1099

        IChat c = (IChat)registry.lookup("chat");

        if (c.entrar("aldfsdfsdfsdfs")) {
            ArrayList<String> nicks = c.lista();
            
            for (String nick : nicks) {
                System.out.println(nick);
            }
        }
      }
}
