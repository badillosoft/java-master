/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cic;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Aula E5
 */
public interface B extends Remote {
    
    void b1(int x) throws RemoteException;
    
    boolean b2(String mensaje) throws RemoteException;
    
}
