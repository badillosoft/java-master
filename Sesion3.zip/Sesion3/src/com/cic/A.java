/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cic;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author Aula E5
 */
public interface A extends Remote {
    
    int a1(String mensaje) throws RemoteException;
    
    boolean a2(B b) throws RemoteException;
    
}
