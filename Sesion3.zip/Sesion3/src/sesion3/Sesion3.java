/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sesion3;

import java.util.function.Predicate;

/**
 *
 * @author Aula E5
 */
public class Sesion3 {

    static int[] filtro(int[] valores) {
        int[] nuevos = new int[valores.length];
        int p = 0;
        for (int i = 0; i < valores.length; i++) {
            int aux = valores[i];
            if (aux % 2 == 0) {
                nuevos[p++] = aux;
            }
        }
        return nuevos;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] x = new int[]{
            1, 2, 3, 4, 5, 20, 30
        };
        
        int[] filtrados = Sesion3.filtro(x);
        
        for (int i = 0; i < filtrados.length; i++) {
            System.out.println(filtrados[i]);
        }
    }
    
}
